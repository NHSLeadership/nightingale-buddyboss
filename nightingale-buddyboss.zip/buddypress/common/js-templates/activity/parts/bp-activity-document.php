<script type="text/html" id="tmpl-activity-document">
	<div class="dropzone closed" id="activity-post-document-uploader"></div>
</script>
