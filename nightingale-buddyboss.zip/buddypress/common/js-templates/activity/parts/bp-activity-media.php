<script type="text/html" id="tmpl-activity-media">
	<div class="dropzone closed" id="activity-post-media-uploader"></div>
</script>
