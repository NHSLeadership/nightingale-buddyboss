<?php
/**
 * Activity Comments JS Templates
 *
 * @version BuddyBoss 1.0.0
 */
?>
<script type="text/html" id="tmpl-activity-comments-loading-message">
	<div id="bp-activity-comments-ajax-loader"><?php bp_nouveau_user_feedback( 'activity-comments-loading' ); ?></div>
</script>
