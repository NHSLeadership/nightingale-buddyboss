<script type="text/html" id="tmpl-bp-messages-single-load-more">
	<button type="button" class="button" style="display: none;"><i class="dashicons dashicons-update animate-spin"></i><?php _e( 'Load previous messages', 'buddyboss' ); ?></button>
</script>