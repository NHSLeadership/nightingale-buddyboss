<script type="text/html" id="tmpl-bp-messages-editor">
    <div id="message_content" name="message_content" tabindex="3"></div>
</script>
