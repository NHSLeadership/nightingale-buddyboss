<script type="text/html" id="tmpl-messages-document">
	<div class="dropzone closed" id="messages-post-document-uploader"></div>
</script>
