<script type="text/html" id="tmpl-messages-media">
	<div class="dropzone closed" id="messages-post-media-uploader"></div>
</script>