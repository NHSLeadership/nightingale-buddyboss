<script type="text/html" id="tmpl-bp-messages-loading">
    <i class="dashicons dashicons-update animate-spin"></i>
</script>